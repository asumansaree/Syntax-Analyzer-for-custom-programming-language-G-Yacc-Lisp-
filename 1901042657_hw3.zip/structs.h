struct explist
{
    float val;
    struct explist* tail;
};